import React, { Component } from "react";

class MyRefSub2 extends Component {
  render() {
    return <div></div>;
  }
}

export default MyRefSub2;
