import React, { Component } from "react";

class MyRefSub1 extends Component {
  render() {
    return <div></div>;
  }
}

export default MyRefSub1;
