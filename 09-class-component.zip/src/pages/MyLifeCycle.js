import React, { Component } from "react";

class MyLifeCycle extends Component {
  render() {
    return <div></div>;
  }
}

export default MyLifeCycle;
