import React, { Component } from "react";

class MyRef extends Component {
  render() {
    return <div></div>;
  }
}

export default MyRef;
